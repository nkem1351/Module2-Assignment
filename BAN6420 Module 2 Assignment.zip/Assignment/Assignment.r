

# Define the zip file and output folder
zip_file <- "Employee Profile.zip"
output_folder <- "Employee Profile"

# Unzip the folder
unzip(zip_file, exdir = output_folder)

# Read and display the CSV file
csv_file <- file.path(output_folder, "NATHANIEL_FORD.csv")
employee_data <- read.csv(csv_file)

# Print the data
print(employee_data)
